extern int sqlite_main(int argc, char *argv[]);

int main(int argc, char *argv[])
{
    return sqlite_main(argc, argv);
}
