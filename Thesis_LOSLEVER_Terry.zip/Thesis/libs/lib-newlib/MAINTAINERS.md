Maintainers List
================

For notes on how to read this information, please refer to `MAINTAINERS.md` in
the main Unikraft repository.

	NEWLIB-UNIKRAFT
	M:	Felipe Huici <felipe.huici@neclab.eu>
	M:	Florian Schmidt <florian.schmidt@neclab.eu>
	L:	minios-devel@lists.xen.org
	F: *
