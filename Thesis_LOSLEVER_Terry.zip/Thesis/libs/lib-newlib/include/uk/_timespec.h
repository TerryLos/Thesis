#ifndef __NEWLIB_GLUE_UK__TIMESPEC_H__
#define __NEWLIB_GLUE_UK__TIMESPEC_H__

#define __NEED_time_t
#define __NEED_struct_timespec
#include <uk/time_types.h>

/* newlib guards */
#define __time_t_defined

#endif /* __NEWLIB_GLUE_UK__TIMESPEC_H__ */
