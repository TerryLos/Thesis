#ifndef __NEWLIB_GLUE_SYS_TIMESPEC_H__
#define __NEWLIB_GLUE_SYS_TIMESPEC_H__

#include <uk/_timespec.h>

#endif /* __NEWLIB_GLUE_SYS_TIMESPEC_H__ */
