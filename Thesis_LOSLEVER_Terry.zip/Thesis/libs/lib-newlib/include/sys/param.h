#ifndef _NEWLIB_GLUE_SYS_PARAM_H_
#define _NEWLIB_GLUE_SYS_PARAM_H_

#include_next <sys/param.h>

#define MAXSYMLINKS 20

#endif
