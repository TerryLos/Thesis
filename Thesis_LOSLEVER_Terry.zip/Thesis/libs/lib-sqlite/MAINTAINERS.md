Maintainers List
================

For notes on how to read this information, please refer to `MAINTAINERS.md` in
the main Unikraft repository.

	LIBSQLITE-UNIKRAFT
	M:  Gaulthier Gain <gaulthier.gain@uliege.be>
	M:  Felipe Huici <felipe.huici@neclab.eu>
	L:  minios-devel@lists.xen.org
	F: *
