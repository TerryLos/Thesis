#ifndef _SYS__PTHREADTYPES_H_
#define _SYS__PTHREADTYPES_H_

#include <pthread.h>

#endif /* _SYS__PTHREADTYPES_H_ */
