#ifndef __PTE_TYPES_H__
#define __PTE_TYPES_H__

#include <sys/timeb.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned int tid_t;

typedef int pid_t;

#ifdef __cplusplus
}
#endif

#endif /* __PTE_TYPES_H__ */
