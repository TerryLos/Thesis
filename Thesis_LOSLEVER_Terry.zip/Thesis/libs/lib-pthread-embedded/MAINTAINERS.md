Maintainers List
================

For notes on how to read this information, please refer to `MAINTAINERS.md` in
the main Unikraft repository.

	PTHREAD-EMBEDDED-UNIKRAFT
	M:	Costin Lupu <costin.lupu@cs.pub.ro>
	L:	minios-devel@lists.xen.org
	F: *
