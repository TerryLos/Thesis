******************************
External Platform Development
******************************
External platform development is exactly like developing an internal
platform, so please refer to that section of the developer's
guide. The only exceptions are that points 5, 7, and 8 in that guide do not
apply to an external library.
