#ifndef _UK_VERSION_H
#define _UK_VERSION_H

void uk_version(void);

#endif /* _UK_VERSION_H */
